package org.crazyit.cloud;

public class PersonController implements PersonClient {

	public String hello() {
		// TODO Auto-generated method stub
		return null;
	}

	public Person getPerson(Integer personId) {
		// TODO Auto-generated method stub
		return null;
	}

}
