package org.crazyit.cloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestInterceptorMain {

	public static void main(String[] args) {
		SpringApplication.run(TestInterceptorMain.class, args);
	}

}
