package org.crazyit.cloud.config;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.context.annotation.Configuration;

//@RibbonClient(name="cloud-provider", configuration=MyConfig.class)
public class CloudProviderConfig {

}
