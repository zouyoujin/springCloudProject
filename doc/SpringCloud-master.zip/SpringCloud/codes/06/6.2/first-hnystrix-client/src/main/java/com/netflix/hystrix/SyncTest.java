package com.netflix.hystrix;

import java.util.concurrent.Future;

import com.netflix.hystrix.HystrixThreadPool.Factory;
import com.netflix.hystrix.crazyit.run.SyncCommand;

public class SyncTest {

	public static void main(String[] args) throws Exception {
		SyncCommand c = new SyncCommand();		
		String reuslt = c.execute();
		
		

	}

}
