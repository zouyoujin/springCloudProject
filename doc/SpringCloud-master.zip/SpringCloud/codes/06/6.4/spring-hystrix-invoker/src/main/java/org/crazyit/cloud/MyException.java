package org.crazyit.cloud;

public class MyException extends RuntimeException {

}
